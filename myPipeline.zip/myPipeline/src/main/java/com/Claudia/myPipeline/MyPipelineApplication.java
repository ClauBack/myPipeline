package com.Claudia.myPipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPipelineApplication.class, args);
	}

}
